package com.shipping.param;
import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;

@Getter
@Setter
public class TrackParam implements Serializable{
    String item;
}
